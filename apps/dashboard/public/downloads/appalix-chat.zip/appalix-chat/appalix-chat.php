<?php
/**
 * Plugin Name: Appalix Chat
 * Plugin URI:  https://appalix.ai
 * Description: Embed the Appalix AI chat widget on your WordPress site. Configure it from Settings → Appalix Chat.
 * Version:     1.0.0
 * Author:      Appalix
 * Author URI:  https://appalix.ai
 * License:     GPL-2.0+
 * Text Domain: appalix-chat
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'APPALIX_OPTION_ENDPOINT', 'appalix_api_endpoint' );
define( 'APPALIX_OPTION_API_KEY',  'appalix_api_key' );

// ── Admin menu ───────────────────────────────────────────────────────────────

add_action( 'admin_menu', 'appalix_add_menu' );
function appalix_add_menu() {
    add_options_page(
        'Appalix Chat Settings',
        'Appalix Chat',
        'manage_options',
        'appalix-chat',
        'appalix_settings_page'
    );
}

// ── Settings ─────────────────────────────────────────────────────────────────

add_action( 'admin_init', 'appalix_register_settings' );
function appalix_register_settings() {
    register_setting( 'appalix_settings_group', APPALIX_OPTION_ENDPOINT, [
        'sanitize_callback' => 'esc_url_raw',
        'default'           => '',
    ] );
    register_setting( 'appalix_settings_group', APPALIX_OPTION_API_KEY, [
        'sanitize_callback' => 'sanitize_text_field',
        'default'           => '',
    ] );
}

function appalix_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;

    $endpoint = get_option( APPALIX_OPTION_ENDPOINT, '' );
    $api_key  = get_option( APPALIX_OPTION_API_KEY,  '' );
    $saved    = isset( $_GET['settings-updated'] ) && $_GET['settings-updated'];
    ?>
    <div class="wrap">
        <h1 style="display:flex;align-items:center;gap:10px;">
            <span style="display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;background:#ec732e;border-radius:8px;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 9h8M8 13h5M5 3h14a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H7l-4 3V5a2 2 0 0 1 2-2z" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            Appalix Chat
        </h1>

        <?php if ( $saved ) : ?>
        <div class="notice notice-success is-dismissible"><p>Settings saved. Your chat widget will now appear on all pages of your site.</p></div>
        <?php endif; ?>

        <p style="color:#555;margin-bottom:20px;">
            Enter the credentials from your
            <a href="https://appalix.ai/integrations" target="_blank" rel="noreferrer">Appalix dashboard</a>
            → Integrations → your WordPress integration setup page.
        </p>

        <form method="post" action="options.php">
            <?php settings_fields( 'appalix_settings_group' ); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">
                        <label for="appalix_endpoint">API Endpoint</label>
                    </th>
                    <td>
                        <input
                            type="url"
                            id="appalix_endpoint"
                            name="<?php echo esc_attr( APPALIX_OPTION_ENDPOINT ); ?>"
                            value="<?php echo esc_attr( $endpoint ); ?>"
                            class="regular-text"
                            placeholder="https://api.appalix.ai/webhooks/wordpress/…"
                        />
                        <p class="description">Copy the <strong>API Endpoint</strong> from your Appalix integration setup page.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="appalix_key">API Key</label>
                    </th>
                    <td>
                        <input
                            type="password"
                            id="appalix_key"
                            name="<?php echo esc_attr( APPALIX_OPTION_API_KEY ); ?>"
                            value="<?php echo esc_attr( $api_key ); ?>"
                            class="regular-text"
                            autocomplete="new-password"
                        />
                        <p class="description">Copy the <strong>API Key</strong> from your Appalix integration setup page.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button( 'Save Settings' ); ?>
        </form>

        <?php if ( $endpoint ) : ?>
        <hr />
        <h2>Status</h2>
        <p style="color:#1a7a1a;">
            ✓ Widget is active. Open any page on your site to see the chat widget in the bottom-right corner.
        </p>
        <p style="color:#555;font-size:13px;">
            All conversations are logged in your
            <a href="https://appalix.ai/conversations" target="_blank" rel="noreferrer">Appalix dashboard → Conversations</a>.
        </p>
        <?php else : ?>
        <hr />
        <h2>Next steps</h2>
        <ol style="color:#555;">
            <li>Paste the <strong>API Endpoint</strong> from your Appalix integration page above.</li>
            <li>Paste the <strong>API Key</strong>.</li>
            <li>Click <strong>Save Settings</strong> — the widget will appear on your site immediately.</li>
        </ol>
        <?php endif; ?>
    </div>
    <?php
}

// ── Widget embed ──────────────────────────────────────────────────────────────

add_action( 'wp_footer', 'appalix_embed_widget' );
function appalix_embed_widget() {
    // Skip in admin
    if ( is_admin() ) return;

    $endpoint = get_option( APPALIX_OPTION_ENDPOINT, '' );
    if ( empty( $endpoint ) ) return;

    // Derive integration ID from the last path segment of the endpoint URL
    $integration_id = basename( rtrim( $endpoint, '/' ) );
    if ( empty( $integration_id ) ) return;

    // Widget JS is served from the same API origin as the endpoint
    $parsed      = wp_parse_url( $endpoint );
    $widget_base = esc_url( $parsed['scheme'] . '://' . $parsed['host'] );

    echo '<script>window.AppalixConfig={integrationId:' . wp_json_encode( $integration_id ) . ',apiBase:' . wp_json_encode( $widget_base ) . '};</script>' . "\n";
    echo '<script src="' . $widget_base . '/widget.js" defer></script>' . "\n";
}
